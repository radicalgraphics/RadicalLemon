<?php 

class Model_filter extends CI_Model {
			
		function __construct() {
       
			parent::__construct();
		
		}
		
		
		
}
?>
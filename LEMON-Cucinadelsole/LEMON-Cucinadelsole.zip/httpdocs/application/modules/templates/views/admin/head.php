<title>Lemon Shuttle</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="icon" href="<?php echo site_url('skin/admin/images/favicon.png') ?>" type="image/png">
<script type="text/javascript" src="<?php echo site_url('js/jquery-1.9.1.min.js') ?>"></script> 
<script type="text/javascript" src="<?php echo site_url('js/jquery-ui-1.10.3.custom.min.js') ?>"></script>
<script type="text/javascript" src="<?php echo site_url('js/jquery.jscrollpane.min.js') ?>"></script>
<script type="text/javascript" src="<?php echo site_url('js/jquery.mousewheel.js') ?>"></script>
<script type="text/javascript" src="<?php echo site_url('js/jquery.validate.pack.js') ?>"></script>
<script type="text/javascript" src="<?php echo site_url('js/jquery.form.js') ?>"></script>	
<script type="text/javascript" src="<?php echo base_url('js/tinymce/tinymce.min.js') ?>"></script>	
<script type="text/javascript" src="<?php echo base_url('js/ajaxfileupload.js') ?>"></script>	
<script type="text/javascript" src="<?php echo base_url('js/jQuery.fileinput.js') ?>"></script>
<script type="text/javascript" src="<?php echo base_url('js/jquery.Jcrop.min.js') ?>"></script>
<link rel="stylesheet" type="text/css" href="<?php echo site_url('skin/admin/css/main.css') ?>" >
<link rel="stylesheet" type="text/css" href="<?php echo site_url('skin/admin/css/jquery-ui-1.10.3.custom.css') ?>" >
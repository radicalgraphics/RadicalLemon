<title>La Cucina Del Sole - <?php echo $head['title']; ?></title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0" />
	<meta name="keywords" content="<?php echo $head['meta_keywords']; ?>">
	<meta name="description" content="<?php echo $head['meta_description']; ?>">
	<link rel="icon" href="favicon.png" type="image/png">
	<script type="text/javascript" src="<?php echo site_url('js/jquery-1.9.1.min.js')?>"></script> 
	<script type="text/javascript" src="<?php echo site_url('js/jquery-ui-1.10.3.custom.min.js')?>"></script>
	<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false&amp;language=en"></script>
	<script type="text/javascript" src="<?php echo site_url('js/gmap3.min.js')?>"></script> 
	<script type="text/javascript" src="<?php echo site_url('js/jquery.jcoverflip.js')?>"></script>
	<script type="text/javascript" src="<?php echo site_url('js/jquery.jscrollpane.min.js')?>"></script>
	<script type="text/javascript" src="<?php echo site_url('js/jquery.mousewheel.js')?>"></script>
	<link rel="stylesheet" type="text/css" href="<?php echo site_url('skin/site/css/main.css')?>" >
	<link rel="stylesheet" type="text/css" href="<?php echo site_url('skin/site/css/jquery-ui-1.10.3.custom.css')?>" >
	
	
	
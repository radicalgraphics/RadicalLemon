<div class="lang-links">
	<a class="<?php if ($lang == "nl" ) { echo "active"; } ?>" href="<?php echo base_url()."nl/".uri_string(); ?>">NL</a>
	<span>|</span>
	<a class="<?php if ($lang == "en" ) { echo "active"; } ?>"  href="<?php echo base_url()."en/".uri_string(); ?>">EN</a>
</div>
<div class="lang-line"></div>
<div class="home">
<div class="container-right">
	<img src="<?php echo base_url()."skin/site/images/cucinadelsole_right.png"?>" alt="Cucina Del Sole - right"/>
</div>
<div class="container">
	<img src="<?php echo base_url()."skin/site/images/la_cucina_del_sole_home.jpg"?>" alt="Cucina Del Sole"/>
	<div class="book">
		<img src="<?php echo base_url()."skin/site/images/cucina_del_sole_book.png"?>" alt="Cucina Del Sole"/>
		<div class="buy">	
			<a href="http://www.cucinadicasamia.nl/" target="_blank">
				<img src="<?php echo base_url()."skin/site/images/buy.png"?>" alt="Cucina Del Sole"/>
			</a>
		</div>	
	</div>
</div>
<div class="container-left">
	<img src="<?php echo base_url()."skin/site/images/cucinadelsole_left.png"?>" alt="Cucina Del Sole - left"/>
</div>
</div>
<div class="ls-navigation">
	<?php echo Modules::run('navigation/admin_navigation/getAdminNavigation'); ?>
</div>
<div>CONTENT OF THIS PAGE IS LOCKED!</div>